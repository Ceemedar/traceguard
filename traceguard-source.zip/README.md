# TraceGuard

TraceGuard is a private, owner-operated Android device recovery system. The Android app reports location and device status with the owner's informed consent; the private website shows the latest report and history.

## Project status

The first connected implementation is deployed: Firebase Authentication and Firestore are configured, the React dashboard is live, and the Android app includes owner sign-in, consent, location collection, a local offline queue, and synchronization. Open the [TraceGuard dashboard](https://traceguard-1a8c2.web.app). See [architecture](docs/architecture.md), [permissions](docs/permissions.md), [deployment](docs/deployment.md), and [the phased plan](docs/roadmap.md).

## Repository layout

```text
android/       Android application (Kotlin, Gradle Kotlin DSL)
website/       Private dashboard (React, TypeScript)
firebase/      Firebase Hosting and Firestore configuration
docs/          Architecture, permissions, setup, deployment, and roadmap
```

## Prerequisites for development

- Android Studio with a compatible Android SDK and JDK 17+.
- Node.js and npm for the website.
- Firebase CLI and Java 17+ for Firestore Emulator rules tests and deployment.
- A Firebase project configured for Authentication (Email/Password), Cloud Firestore, and Hosting. The current project is `traceguard-1a8c2`.
- Git for source control.

No Firebase project credentials or private keys belong in source control. The website's public Firebase web configuration is environment-specific; Firebase Security Rules must still protect every record.

## Build

```powershell
cd website
npm ci
npm run build

cd ..\android
.\gradlew.bat :app:assembleDebug
```

The Android debug APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`. Supply the Firebase Android app configuration as `android/app/google-services.json`; this local configuration file is ignored by Git. Supply the web Firebase values through `website/.env.local` using the keys in `.env.example`.

See [the deployment guide](docs/deployment.md) for emulator checks and Hosting release steps. The Android client is an initial implementation; validate permissions, scheduling, offline behavior, and account deletion on the target device before relying on it for recovery.

## Safety and platform limits

TraceGuard is designed for a device owner's own phone. It must use visible, user-approved permissions and Android-required foreground-service notifications. It must not hide system privacy indicators, bypass permission controls, or promise uninterrupted location reporting. Location freshness depends on Android scheduling, permissions, battery policy, connectivity, and device state.
